<?xml version="1.0" encoding="UTF-8"?>
<Ableton MajorVersion="5" MinorVersion="11.0.0" Creator="Ableton Live 11.3.4">
  <LiveSet>
    <Tracks>
      <MidiTrack Id="3" LomId="0">
        <Name>
          <EffectiveName Value="Bass"/>
        </Name>
        <DeviceChain>
          <MainSequencer>
            <AutomationEnvelopes>
              <Envelopes>
                <AutomationEnvelope Id="0">
                  <EnvelopeTarget>
                    <PointeeId Value="23456"/>
                  </EnvelopeTarget>
                  <Automation>
                    <Events>
                      <FloatEvent Time="0" Value="0.2"/>
                      <FloatEvent Time="4" Value="0.5"/>
                      <FloatEvent Time="8" Value="0.8"/>
                      <FloatEvent Time="16" Value="0.3"/>
                    </Events>
                  </Automation>
                </AutomationEnvelope>
                <AutomationEnvelope Id="1">
                  <EnvelopeTarget>
                    <PointeeId Value="23457"/>
                  </EnvelopeTarget>
                  <Automation>
                    <Events>
                      <FloatEvent Time="0" Value="0.7"/>
                      <FloatEvent Time="8" Value="0.4"/>
                      <FloatEvent Time="16" Value="0.9"/>
                    </Events>
                  </Automation>
                </AutomationEnvelope>
              </Envelopes>
            </AutomationEnvelopes>
          </MainSequencer>
          <DeviceChain>
            <Devices>
              <AutoFilter Id="100">
                <UserName Value=""/>
                <PluginFloatParameter Id="23456">
                  <ParameterName Value="Filter Freq"/>
                </PluginFloatParameter>
                <PluginFloatParameter Id="23457">
                  <ParameterName Value="Resonance"/>
                </PluginFloatParameter>
              </AutoFilter>
            </Devices>
          </DeviceChain>
        </DeviceChain>
      </MidiTrack>
      <AudioTrack Id="4" LomId="0">
        <Name>
          <EffectiveName Value="Pad"/>
        </Name>
        <DeviceChain>
          <MainSequencer>
            <AutomationEnvelopes>
              <Envelopes>
                <AutomationEnvelope Id="0">
                  <EnvelopeTarget>
                    <PointeeId Value="34567"/>
                  </EnvelopeTarget>
                  <Automation>
                    <Events>
                      <FloatEvent Time="0" Value="0.0"/>
                      <FloatEvent Time="16" Value="0.6"/>
                      <FloatEvent Time="32" Value="1.0"/>
                    </Events>
                  </Automation>
                </AutomationEnvelope>
              </Envelopes>
            </AutomationEnvelopes>
          </MainSequencer>
          <DeviceChain>
            <Devices>
              <Delay Id="200">
                <UserName Value=""/>
                <PluginFloatParameter Id="34567">
                  <ParameterName Value="Dry/Wet"/>
                </PluginFloatParameter>
              </Delay>
            </Devices>
          </DeviceChain>
        </DeviceChain>
      </AudioTrack>
      <ReturnTrack Id="5" LomId="0">
        <Name>
          <EffectiveName Value="Reverb Return"/>
        </Name>
        <DeviceChain>
          <MainSequencer>
            <AutomationEnvelopes>
              <Envelopes/>
            </AutomationEnvelopes>
          </MainSequencer>
          <DeviceChain>
            <Devices>
              <Reverb Id="300">
                <UserName Value=""/>
                <PluginFloatParameter Id="45678">
                  <ParameterName Value="Decay Time"/>
                </PluginFloatParameter>
              </Reverb>
            </Devices>
          </DeviceChain>
        </DeviceChain>
      </ReturnTrack>
    </Tracks>
  </LiveSet>
</Ableton>
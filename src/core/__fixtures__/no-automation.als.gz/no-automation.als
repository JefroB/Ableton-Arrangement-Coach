<?xml version="1.0" encoding="UTF-8"?>
<Ableton MajorVersion="5" MinorVersion="11.0.0" Creator="Ableton Live 11.3.4">
  <LiveSet>
    <Tracks>
      <MidiTrack Id="1" LomId="0">
        <Name>
          <EffectiveName Value="Lead"/>
        </Name>
        <DeviceChain>
          <MainSequencer>
            <AutomationEnvelopes>
              <Envelopes/>
            </AutomationEnvelopes>
          </MainSequencer>
          <DeviceChain>
            <Devices/>
          </DeviceChain>
        </DeviceChain>
      </MidiTrack>
    </Tracks>
  </LiveSet>
</Ableton>